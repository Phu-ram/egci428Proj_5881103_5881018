package com.example.project_personaldoctor

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.example.project_personaldoctor.Model.User
import com.google.firebase.database.*
import kotlinx.android.synthetic.main.activity_register.*

class RegisterActivity : AppCompatActivity() {
    lateinit var dataReference: DatabaseReference
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)


        dataReference = FirebaseDatabase.getInstance().getReference("dataUsers")

        signUpBtn.setOnClickListener {
            saveData()
            val intent = Intent(this@RegisterActivity,LoginActivity::class.java)
            startActivity(intent)
        }

        val actionbar = supportActionBar
        actionbar!!.title = "Register Page"
        actionbar.setDisplayHomeAsUpEnabled(true)
    }
    private fun saveData(){
        val user_fname = nametxt.text.toString()
        val user_lname = surnameText.text.toString()
        val username = userNameText.text.toString()
        val password = passWordText.text.toString()
        val email = emailTxt.text.toString()

        if(user_fname.isEmpty()||user_lname.isEmpty()||username.isEmpty()||password.isEmpty()||email.isEmpty()) { //alternative to msg == null
            Toast.makeText(applicationContext,"Please fill all the requirement", Toast.LENGTH_SHORT).show()
            return
        }
        else if(username == dataReference.key.toString()){
            userNameText.error = "The username is already used"
            return
        }
        else if(password.length < 8){
            passWordText.error = "Password must be at least 8 characters"
        }

        else{
         //Unique id will be created automatically by firebase (similar to position number)
        val UserData = User(username,password,user_fname,user_lname,email)
         dataReference.child(username).setValue(UserData).addOnCompleteListener{
            Toast.makeText(applicationContext,"The user has been successfully created.", Toast.LENGTH_SHORT).show()
            }
        }

    }
    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }
}
