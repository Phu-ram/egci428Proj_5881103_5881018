package com.example.project_personaldoctor.Model

class User( var username: String, var password: String, var fName: String, var lName: String,var eMail: String) {

    constructor():this("","","","","")
    override fun toString(): String {
     return username.toString()
   }

}