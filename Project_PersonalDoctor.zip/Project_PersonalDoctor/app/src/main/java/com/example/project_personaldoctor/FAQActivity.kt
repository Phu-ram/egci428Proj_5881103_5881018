package com.example.project_personaldoctor

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class FAQActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_faq)
        val actionbar = supportActionBar
        actionbar!!.title = "FAQ Page"
        actionbar.setDisplayHomeAsUpEnabled(true)
    }
    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }
}
