package com.example.project_personaldoctor.Model

class Medicines(val Name:String,val Commercial:String,val Type:String,val Dose:String,val Detail:String) {
}