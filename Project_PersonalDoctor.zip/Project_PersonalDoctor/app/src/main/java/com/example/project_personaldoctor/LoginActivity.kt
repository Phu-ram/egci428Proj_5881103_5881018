package com.example.project_personaldoctor


import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.AsyncTask
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import com.example.project_personaldoctor.Helper.HTTPHelper
import com.example.project_personaldoctor.Model.User
import com.google.gson.Gson
import kotlinx.android.synthetic.main.activity_login.*

class LoginActivity : AppCompatActivity() {
    //private val REQUEST_CODE = 1
    var url = "https://egci428-json-inclass-pae.firebaseio.com/dataUsers/"
    var uname: String? = null
    var pname: String? = null
    var userprofile: User? = null
    private var bitmap: Bitmap?? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        bitmap = BitmapFactory.decodeResource(resources,R.drawable.doctor)
        imageView.setImageBitmap(bitmap)
        signUpBtn.setOnClickListener {
            val RegisterPage = Intent(this, RegisterActivity::class.java)
            startActivity(RegisterPage)
        }
        contactBtn.setOnClickListener {
            val FAQPage = Intent(this,FAQActivity::class.java)
            startActivity(FAQPage)
        }
        signInBtn.setOnClickListener {
            uname = txtUsername.text.toString()
            pname = txtPassword.text.toString()
            if (!uname.isNullOrEmpty() && !pname.isNullOrEmpty()) {
                var asyncTask = object : AsyncTask<String, String, String>() {

                    override fun onPreExecute() {
                        Toast.makeText(this@LoginActivity, "Please wait...", Toast.LENGTH_SHORT).show()
                    }

                    override fun doInBackground(vararg p0: String?): String {
                        val helper = HTTPHelper()
                        return helper.getHTTPData(url+uname+".json")
                    }

                    override fun onPostExecute(result: String?) {
                        if (result != "null") {
                            // keep the value under userprofile object
                            userprofile = Gson().fromJson(result,User::class.java)
                            if(pname == userprofile!!.password){
                                val intent = Intent(this@LoginActivity,HomePageActivity/*MainActivity*/::class.java)
                                intent.putExtra("UserN",uname)
                                startActivity(intent)
                            }
                            else{
                                Toast.makeText( this@LoginActivity,"Password is not matched", Toast.LENGTH_SHORT).show()
                            }
                        }
                        // no user found
                        else {
                            Toast.makeText(this@LoginActivity, "Username is not found", Toast.LENGTH_SHORT).show()
                        }
                    }

                }
                asyncTask.execute()

            }

        }


    }

//    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
//        super.onActivityResult(requestCode, resultCode, data)
//        var stream: InputStream? = null
//        if(requestCode == REQUEST_CODE && resultCode == Activity.RESULT_OK)
//            try{
//                if(bitmap!= )
//            }
//    }



}
