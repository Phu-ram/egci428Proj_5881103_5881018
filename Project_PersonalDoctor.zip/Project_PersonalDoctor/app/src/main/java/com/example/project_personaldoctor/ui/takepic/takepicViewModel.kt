package com.example.project_personaldoctor.ui.takepic

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class takepicViewModel : ViewModel() {

    private val _text = MutableLiveData<String>().apply {
        value = "This is taking picture Fragment"
    }
    val text: LiveData<String> = _text
}